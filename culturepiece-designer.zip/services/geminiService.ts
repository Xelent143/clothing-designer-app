
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Concept, ProductionAssets, Gender } from "../types";

// Helper to get client with current key
const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
};

export const checkApiKey = async (): Promise<boolean> => {
  const win = window as any;
  if (win.aistudio && win.aistudio.hasSelectedApiKey) {
    return await win.aistudio.hasSelectedApiKey();
  }
  return !!process.env.API_KEY;
};

export const promptForApiKey = async (): Promise<void> => {
  const win = window as any;
  if (win.aistudio && win.aistudio.openSelectKey) {
    await win.aistudio.openSelectKey();
  } else {
    alert("AI Studio environment not detected. Please ensure you are running in the correct environment.");
  }
};

/**
 * Extracts MIME type and raw base64 data from a Data URL
 */
const parseDataUrl = (dataUrl: string) => {
  const regex = /^data:(image\/[a-zA-Z+]+);base64,(.+)$/;
  const matches = dataUrl.match(regex);
  if (matches) {
    return { mimeType: matches[1], data: matches[2] };
  }
  return { mimeType: 'image/png', data: dataUrl };
};

/**
 * Retry utility for handling transient 503/429 errors
 */
const retryOperation = async <T>(operation: () => Promise<T>, retries = 3, delay = 2000): Promise<T> => {
  try {
    return await operation();
  } catch (error: any) {
    let errString = "";
    try { errString = error.message || String(error); } catch (e) { errString = "Unknown"; }

    const isTransient = 
      error.status === 503 || 
      error.status === 500 ||
      errString.includes('503') || 
      errString.includes('overloaded') || 
      errString.includes('Service Unavailable') ||
      errString.includes('Internal Server Error');
    
    if (isTransient && retries > 0) {
      console.warn(`Operation failed with ${error.status || 'error'}. Retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return retryOperation(operation, retries - 1, delay * 2); 
    }
    throw error;
  }
};

const generateWithFallback = async (
  ai: GoogleGenAI, 
  primaryModel: string, 
  fallbackModel: string, 
  contents: any, 
  config: any
): Promise<GenerateContentResponse> => {
  const callModel = async (model: string, cfg: any) => {
     return await ai.models.generateContent({
        model: model,
        contents,
        config: cfg
      });
  };

  try {
    return await retryOperation<GenerateContentResponse>(() => callModel(primaryModel, config));
  } catch (error: any) {
    let errString = "";
    try { errString = error.message || String(error); } catch (e) { errString = "Unknown error"; }

    const shouldFallback = 
      (error.status === 429) || 
      (error.status === 503) ||
      (error.status === 500) ||
      (error.status === 404) ||
      errString.includes('RESOURCE_EXHAUSTED') || 
      errString.includes('Quota exceeded') ||
      errString.includes('limit: 0') ||
      errString.includes('overloaded') ||
      errString.includes('Service Unavailable') ||
      errString.includes('not found');

    if (shouldFallback) {
      const fallbackConfig = { ...config };
      if (fallbackConfig.imageConfig) {
        const { imageSize, ...restImageConfig } = fallbackConfig.imageConfig;
        fallbackConfig.imageConfig = restImageConfig;
      }
      return await retryOperation<GenerateContentResponse>(() => callModel(fallbackModel, fallbackConfig));
    }
    throw error;
  }
};

export const generateConceptDescriptions = async (category: string, gender: Gender, preset?: string, detail?: string, outputStyle?: 'genz' | 'minimalistic' | 'genz-us' | 'european'): Promise<Omit<Concept, 'imageBase64'>[]> => {
  const ai = getClient();
  let styleInstruction = '';
  if (outputStyle === 'genz-us') {
      styleInstruction = 'The design MUST be tailored for the US-based Black American Gen Z audience. Focus on stacked/baggy fits, unconventional fabrics like velour or coated denim, and unique embellishments like rhinestone patterns or puff prints.';
  } else if (outputStyle === 'european') {
      styleInstruction = 'The design MUST be tailored for a European audience. Focus on clean, tailored silhouettes, technical fabrics, and minimalist details.';
  }

  const prompt = `Act as a high-end streetwear designer. Create 2 distinct ${gender} ${category} concepts. Aesthetic: ${styleInstruction || 'Black American Streetwear'}. Return JSON with id, title, description.`;

  try {
    const response = await generateWithFallback(
      ai,
      'gemini-3-flash-preview',
      'gemini-3-flash-preview', 
      prompt, 
      {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.INTEGER },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
            },
            propertyOrdering: ["id", "title", "description"],
          },
        },
      }
    );

    let text = response.text || "";
    text = text.replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(text);
  } catch (error) {
    console.error("Error generating concepts:", error);
    throw error;
  }
};

export const generateConceptImage = async (conceptDesc: string, category: string, logoBase64?: string | null): Promise<string> => {
  const ai = getClient();
  let imagePrompt = `2D technical fashion flat sketch of ${category}. Details: ${conceptDesc}. High-end streetwear, clean lines, white background. No real brand logos.`;

  const parts: any[] = [];
  if (logoBase64) {
    const { mimeType, data } = parseDataUrl(logoBase64);
    imagePrompt += `\nIntegrate the provided logo creatively.`;
    parts.push({ text: imagePrompt }, { inlineData: { mimeType, data } });
  } else {
    parts.push({ text: imagePrompt });
  }

  const response = await generateWithFallback(ai, 'gemini-2.5-flash-image', 'gemini-2.5-flash-image', { parts }, { imageConfig: { aspectRatio: "4:3" } });
  return response.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data || "";
};

export const generateProductionAssets = async (
  baseImage: string, 
  description: string, 
  category: string,
  gender: Gender,
  onProgress?: (msg: string, percent: number) => void
): Promise<ProductionAssets> => {
  const ai = getClient();
  const generateVariant = async (action: string, refImage: string, aspectRatio: string = "1:1", extraContext: string = "", usePro: boolean = true): Promise<string> => {
    const { mimeType, data } = parseDataUrl(refImage);
    const fullPrompt = `Task: Create a photorealistic ${action} of the garment. Consistency: Exact same design/color/logo. No real-world brands. Design context: ${description}. ${extraContext}`;
    const response = await generateWithFallback(ai, usePro ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image', 'gemini-2.5-flash-image', { parts: [{ text: fullPrompt }, { inlineData: { mimeType, data } }] }, { imageConfig: { aspectRatio: aspectRatio as any, imageSize: usePro ? "2K" : undefined } });
    return response.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data || refImage;
  };

  // ONE BY ONE REQUESTS
  if (onProgress) onProgress("Rendering Front View...", 10);
  const front = await generateVariant("Front View Flatlay", baseImage, "1:1", "Photorealistic studio shot.", true);
  
  if (onProgress) onProgress("Rendering Back View...", 30);
  const back = await generateVariant("Back View Flatlay", front, "1:1", "Show rear side.", true);
  
  if (onProgress) onProgress("Rendering Side Profile...", 50);
  const side = await generateVariant("Side Profile", front, "1:1", "Side angle.", false);
  
  if (onProgress) onProgress("Rendering Texture Details...", 70);
  const closeup = await generateVariant("Texture Detail", front, "1:1", "Macro zoom.", false);
  
  if (onProgress) onProgress("Finalizing Lifestyle Campaign...", 90);
  const lifestyle = await generateVariant("Lifestyle Campaign", front, "3:4", `Model: ${gender} Black American model in urban setting. Influencer style.`, true);

  if (onProgress) onProgress("Complete", 100);
  return { front, back, closeup, side, lifestyle };
};

export const generateGhostMannequin = async (frontImageB64: string, backImageB64: string | null, onProgress?: (msg: string, percent: number) => void): Promise<{ front: string; back: string | null }> => {
  const ai = getClient();
  const frontInfo = parseDataUrl(frontImageB64);
  const frontPrompt = `Task: Transform photo into professional "ghost mannequin" e-commerce asset. Light gray background. Hyper-realistic 2K.`;
  const frontResponse = await generateWithFallback(ai, 'gemini-3-pro-image-preview', 'gemini-2.5-flash-image', { parts: [{ text: frontPrompt }, { inlineData: frontInfo }] }, { imageConfig: { aspectRatio: "3:4", imageSize: "2K" } });
  const generatedFront = frontResponse.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data || "";

  let generatedBack: string | null = null;
  if (backImageB64) {
      const backInfo = parseDataUrl(backImageB64);
      const backPrompt = `Create the BACK VIEW ghost mannequin image consistent with the generated front view.`;
      const backResponse = await generateWithFallback(ai, 'gemini-3-pro-image-preview', 'gemini-2.5-flash-image', { parts: [{ text: backPrompt }, { inlineData: backInfo }, { inlineData: { mimeType: 'image/png', data: generatedFront }}] }, { imageConfig: { aspectRatio: "3:4", imageSize: "2K" } });
      generatedBack = backResponse.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data || null;
  }
  return { front: generatedFront, back: generatedBack };
};

export const generateBanners = async (productImageB64: string, preset: string, aspectRatio: string, holiday?: string, deal?: string): Promise<string[]> => {
  const ai = getClient();
  const prodInfo = parseDataUrl(productImageB64);
  const mainPrompt = `Creative Director Task: Professional social media banner for streetwear. Preset: ${preset}. Holiday: ${holiday}. Deal: ${deal}. 2K quality.`;
  
  const generate = async () => {
    const res = await generateWithFallback(ai, 'gemini-3-pro-image-preview', 'gemini-2.5-flash-image', { parts: [{ text: mainPrompt }, { inlineData: prodInfo }] }, { imageConfig: { aspectRatio: (aspectRatio === "4:5" || aspectRatio === "2:3" ? "3:4" : aspectRatio) as any, imageSize: "2K" } });
    return res.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data || "";
  };

  // ONE BY ONE REQUESTS
  const banner1 = await generate();
  const banner2 = await generate();
  return [banner1, banner2];
};

export const generateModelPhotoshoot = async (
  productImageB64: string,
  modelType: 'ai' | 'real',
  modelImageB64?: string | null,
  aiConfig?: any
): Promise<string> => {
  const ai = getClient();
  const prodInfo = parseDataUrl(productImageB64);
  const parts: any[] = [];

  if (modelType === 'real' && modelImageB64) {
    const modelInfo = parseDataUrl(modelImageB64);
    const prompt = `TASK: Virtual try-on. Place garment from product image onto the human model. Perfect fit, drape, and lighting. 2K resolution.`;
    parts.push({ text: prompt }, { inlineData: prodInfo }, { inlineData: modelInfo });
  } else {
    const prompt = `TASK: Lifestyle photoshoot. ${aiConfig.gender} ${aiConfig.ethnicity} model (${aiConfig.age}) in ${aiConfig.scene} environment. Action: ${aiConfig.action}. Model must wear the exact garment from the product image. 2K resolution.`;
    parts.push({ text: prompt }, { inlineData: prodInfo });
  }

  const response = await generateWithFallback(ai, 'gemini-3-pro-image-preview', 'gemini-2.5-flash-image', { parts }, { imageConfig: { aspectRatio: "3:4", imageSize: "2K" } });
  return response.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data || "";
};
