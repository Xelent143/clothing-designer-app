
import React, { useEffect, useState } from 'react';
import { getAllUsers, addCreditsToUser, subscribeToGlobalStats } from '../services/userService';
import { UserProfile } from '../types';
import { Button } from './Button';

interface AdminPanelProps {
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [globalStats, setGlobalStats] = useState({ totalGenerations: 0 });
  const [creditInputs, setCreditInputs] = useState<Record<string, string>>({});
  const [searchQuery, setSearchQuery] = useState('');

  const fetchData = async () => {
    setLoading(true);
    const data = await getAllUsers();
    setUsers(data.sort((a, b) => b.createdAt - a.createdAt));
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
    const unsubStats = subscribeToGlobalStats(setGlobalStats);
    return () => unsubStats();
  }, []);

  const handleAddCredits = async (uid: string) => {
    const amountStr = creditInputs[uid];
    if (!amountStr) return;
    const amount = parseInt(amountStr);
    if (isNaN(amount) || amount === 0) return;
    await addCreditsToUser(uid, amount);
    setCreditInputs(prev => ({ ...prev, [uid]: '' }));
    await fetchData();
  };

  const handleInputChange = (uid: string, val: string) => {
    setCreditInputs(prev => ({ ...prev, [uid]: val }));
  };

  const filteredUsers = users.filter(user => 
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-4">
      <div className="bg-neutral-900 border border-white/20 w-full max-w-5xl h-[80vh] flex flex-col shadow-2xl">
        <div className="p-6 border-b border-white/10 flex flex-col md:flex-row justify-between items-center bg-black gap-4">
          <div className="flex-1">
            <h2 className="text-2xl font-bold brand-font text-white uppercase tracking-wider">Dashboard</h2>
            <p className="text-xs text-purple-400 uppercase tracking-widest font-bold">Platform Pulse: {globalStats.totalGenerations.toLocaleString()} Pieces Created</p>
          </div>
          
          <div className="relative group w-full md:w-auto">
            <input 
              type="text" 
              placeholder="Search users..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-neutral-900 border border-white/20 pl-4 pr-4 py-2 text-sm text-white focus:border-purple-500 outline-none w-full md:w-64 transition-colors"
            />
          </div>

          <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors ml-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>

        {/* Global Analytics Section */}
        <div className="px-6 py-4 bg-purple-900/10 border-b border-white/5">
           <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-black/40 border border-purple-500/20 rounded">
                 <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block mb-1">Lifetime Generations</span>
                 <span className="text-3xl font-bold brand-font text-white tabular-nums">{globalStats.totalGenerations.toLocaleString()}</span>
              </div>
              <div className="p-4 bg-black/40 border border-purple-500/20 rounded">
                 <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block mb-1">Active Users</span>
                 <span className="text-3xl font-bold brand-font text-white">{users.length}</span>
              </div>
              <div className="p-4 bg-black/40 border border-purple-500/20 rounded">
                 <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block mb-1">Credits in Economy</span>
                 <span className="text-3xl font-bold brand-font text-white">{users.reduce((acc, u) => acc + u.credits, 0)}</span>
              </div>
           </div>
        </div>

        <div className="flex-grow overflow-auto p-6">
          {loading ? (
            <div className="flex items-center justify-center h-full text-gray-500 animate-pulse">Loading Users...</div>
          ) : (
            <div className="w-full overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/20 text-xs text-gray-400 uppercase tracking-widest">
                    <th className="p-4 font-normal">User Email</th>
                    <th className="p-4 font-normal">Role</th>
                    <th className="p-4 font-normal">Credits</th>
                    <th className="p-4 font-normal">Joined</th>
                    <th className="p-4 font-normal text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map(user => (
                    <tr key={user.uid} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="p-4 text-sm font-medium text-white">{user.email}</td>
                      <td className="p-4 text-sm">
                        <span className={`px-2 py-1 text-[10px] font-bold uppercase rounded-full ${user.role === 'admin' ? 'bg-purple-900 text-purple-200' : 'bg-gray-800 text-gray-300'}`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="p-4 text-sm font-bold text-white text-lg">{user.credits}</td>
                      <td className="p-4 text-xs text-gray-500">{new Date(user.createdAt).toLocaleDateString()}</td>
                      <td className="p-4 text-right">
                        <div className="flex justify-end gap-2">
                          <input 
                            type="number" 
                            placeholder="+/-" 
                            className="w-20 bg-black border border-gray-700 px-2 py-1 text-sm text-white focus:border-purple-500 outline-none"
                            value={creditInputs[user.uid] || ''}
                            onChange={(e) => handleInputChange(user.uid, e.target.value)}
                          />
                          <Button variant="secondary" className="py-1 px-3 text-xs" onClick={() => handleAddCredits(user.uid)}>
                            Update
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
