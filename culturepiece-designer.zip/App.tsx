
import React, { useState, useEffect, useRef } from 'react';
import { AppStep, Gender, CATEGORIES, Concept, ProductionAssets, UserProfile, SOCCER_PRESETS, AppMode, BANNER_PRESETS, ASPECT_RATIOS, HOLIDAY_PRESETS, PUFFER_JACKET_PRESETS, AI_MODEL_ETHNICITY, AI_MODEL_AGE, AI_MODEL_SCENE, AI_MODEL_ACTION } from './types';
import { Button } from './components/Button';
import { LoadingScreen } from './components/LoadingScreen';
import { TechPack } from './components/TechPack';
import { AdminPanel } from './components/AdminPanel';
import { subscribeToGlobalStats } from './services/userService';
import { 
  generateConceptDescriptions, 
  generateConceptImage, 
  generateProductionAssets,
  generateGhostMannequin,
  generateBanners,
  generateModelPhotoshoot,
  checkApiKey,
  promptForApiKey
} from './services/geminiService';

// --- Category Icons ---
// Updated icon components to accept className prop for styling
const TShirtIcon = ({ className }: { className?: string }) => (<svg className={className} xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20.38 3.46 16 2a4 4 0 0 0-8 0L3.62 3.46a2 2 0 0 0 1.34 3.23l.54.16a2 2 0 0 0 1.6 0l.54-.16a2 2 0 0 1 1.6 0l.54.16a2 2 0 0 1 1.6 0l.54-.16a2 2 0 0 1 1.6 0l.54.16a2 2 0 0 1 1.6 0l.54.16a2 2 0 0 0 1.6 0l.54-.16a2 2 0 0 0 1.34-3.23z"/><path d="M12 13v8"/></svg>);
const TrousersIcon = ({ className }: { className?: string }) => (<svg className={className} xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22a2 2 0 0 0 2-2V8.5a2.5 2.5 0 1 0-5 0V20a2 2 0 0 0 2 2Z"/><path d="M14 20a2 2 0 0 0 2-2V8.5a2.5 2.5 0 1 0-5 0V20a2 2 0 0 0 2 2Z"/><path d="M6 2h12"/></svg>);
const ShortsIcon = ({ className }: { className?: string }) => (<svg className={className} xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 14a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-2z"/><path d="M18 12h-2a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2z"/><path d="M6 2h12"/></svg>);
const HoodieIcon = ({ className }: { className?: string }) => (<svg className={className} xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M16 14a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-2z"/><path d="M12 18v3"/><path d="m11 12-3-3a5 5 0 0 1 8-4h.5a3.5 3.5 0 0 1 3.5 3.5v.5a5 5 0 0 1-4 8z"/></svg>);
const JacketIcon = ({ className }: { className?: string }) => (<svg className={className} xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 12h-4.24a1 1 0 0 0-.97.72L16 16h-4l-.79-3.28a1 1 0 0 0-.97-.72H6"/><path d="M6 9h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z"/><path d="M8 12v-2a2 2 0 1 1 4 0v2"/><path d="M12 12v2a2 2 0 1 0 4 0v-2"/></svg>);
const LeggingsIcon = ({ className }: { className?: string }) => (<svg className={className} xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M10.5 20.5 8 4h8l-2.5 16.5"/><path d="M7 8h10"/></svg>);
const SoccerIcon = ({ className }: { className?: string }) => (<svg className={className} xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v7l4-2-4 2"/><path d="m5 12 7-4 7 4"/><path d="M5 12v4l7 4 7-4v-4"/><path d="m12 12-7-4"/></svg>);

const CATEGORY_ICONS: Record<string, React.FC<{ className?: string }>> = {
  "Trousers": TrousersIcon,
  "Shorts": ShortsIcon,
  "Tracksuits": HoodieIcon,
  "T-Shirts": TShirtIcon,
  "Denim Jackets": JacketIcon,
  "Puffer Jackets": JacketIcon,
  "Hunting Jackets": JacketIcon,
  "Crop Tops": TShirtIcon,
  "Leggings": LeggingsIcon,
  "Hoodies": HoodieIcon,
  "Soccer Uniforms": SoccerIcon,
  "American Football Uniform": SoccerIcon,
  "Baseball Jersey": TShirtIcon,
  "Ice Hockey Jersey": HoodieIcon,
  "Ski Jackets": JacketIcon,
};

// Common icon components updated to accept className prop
const BackIcon = ({ className }: { className?: string }) => <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>;
const DownloadIcon = ({ className }: { className?: string }) => <svg className={className} xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>;
const UploadIcon = ({ className }: { className?: string }) => <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>;
const AdminIcon = ({ className }: { className?: string }) => <svg className={className} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>;

const App: React.FC = () => {
  const [globalStats, setGlobalStats] = useState({ totalGenerations: 0 });
  const [appMode, setAppMode] = useState<AppMode>('designer');
  const [step, setStep] = useState<AppStep>(AppStep.CATEGORY_SELECT);
  const [selectedGender, setSelectedGender] = useState<Gender>(Gender.MALE);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [concepts, setConcepts] = useState<Concept[]>([]);
  const [selectedConcept, setSelectedConcept] = useState<Concept | null>(null);
  const [productionAssets, setProductionAssets] = useState<ProductionAssets | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingMsg, setLoadingMsg] = useState<string>("");
  const [loadingMsgSub, setLoadingMsgSub] = useState<string>("");
  const [loadingProgress, setLoadingProgress] = useState<number>(0);
  const [hasKey, setHasKey] = useState<boolean>(false);
  const [showTechPack, setShowTechPack] = useState<boolean>(false);
  const [showAdminPanel, setShowAdminPanel] = useState<boolean>(false);
  const [selectedPreset, setSelectedPreset] = useState<string>(SOCCER_PRESETS[0]);
  const [showStyleChoiceModal, setShowStyleChoiceModal] = useState(false);
  const [logo, setLogo] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Ghost State
  const [ghostFrontImage, setGhostFrontImage] = useState<string | null>(null);
  const [ghostBackImage, setGhostBackImage] = useState<string | null>(null);
  const [generatedGhostImages, setGeneratedGhostImages] = useState<{ front: string; back: string | null } | null>(null);
  const ghostFrontRef = useRef<HTMLInputElement>(null);
  const ghostBackRef = useRef<HTMLInputElement>(null);

  // Banner State
  const [bannerProductImage, setBannerProductImage] = useState<string | null>(null);
  const [selectedBannerPreset, setSelectedBannerPreset] = useState<string>(BANNER_PRESETS[0]);
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<string>(Object.values(ASPECT_RATIOS)[0]);
  const [generatedBanners, setGeneratedBanners] = useState<string[]>([]);
  const [selectedHoliday, setSelectedHoliday] = useState<string>('None');
  const [dealText, setDealText] = useState<string>('');
  const bannerProductRef = useRef<HTMLInputElement>(null);

  // Photoshoot State
  const [photoshootProductImage, setPhotoshootProductImage] = useState<string | null>(null);
  const [photoshootModelType, setPhotoshootModelType] = useState<'ai' | 'real' | null>(null);
  const [photoshootRealModelImage, setPhotoshootRealModelImage] = useState<string | null>(null);
  const [photoshootAiConfig, setPhotoshootAiConfig] = useState({
      gender: Gender.MALE,
      ethnicity: AI_MODEL_ETHNICITY[0],
      age: AI_MODEL_AGE[0],
      scene: AI_MODEL_SCENE[0],
      action: AI_MODEL_ACTION[0]
  });
  const [photoshootResultImage, setPhotoshootResultImage] = useState<string | null>(null);
  const photoshootProductRef = useRef<HTMLInputElement>(null);
  const photoshootRealModelRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    checkApiKey().then(setHasKey);
    const unsubStats = subscribeToGlobalStats((data) => setGlobalStats(data));
    return () => unsubStats();
  }, []);

  const handleKeySelect = async () => { await promptForApiKey(); setHasKey(true); };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: React.Dispatch<React.SetStateAction<string | null>>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => setter(reader.result as string);
          reader.readAsDataURL(file);
      }
  };

  const startDesignProcess = async (category: string, style?: any) => {
    if (!hasKey) await handleKeySelect();
    setLoading(true);
    setLoadingMsg(`Analyzing Trends`);
    setLoadingMsgSub("Scraping Streetwear Data...");
    setLoadingProgress(10);
    try {
      const descriptions = await generateConceptDescriptions(category, selectedGender, undefined, undefined, style);
      setLoadingMsg("Generating Prototypes");
      setLoadingProgress(30);
      const conceptsWithImages = await Promise.all(descriptions.map(async (desc) => {
        const b64 = await generateConceptImage(desc.description, category, logo);
        return { ...desc, imageBase64: b64 };
      }));
      setConcepts(conceptsWithImages.filter(c => c.imageBase64));
      setStep(AppStep.CONCEPT_SELECTION);
    } catch (e: any) { alert(e.message); } finally { setLoading(false); }
  };

  const finalizeDesign = async (concept: Concept) => {
    setSelectedConcept(concept);
    setLoading(true);
    setLoadingMsg("Production Studio");
    setLoadingProgress(0);
    try {
      const assets = await generateProductionAssets(concept.imageBase64, concept.description, selectedCategory, selectedGender, (m, p) => { setLoadingMsgSub(m); setLoadingProgress(p); });
      setProductionAssets(assets);
      setStep(AppStep.PRODUCTION_VIEW);
    } catch (e: any) { alert(e.message); } finally { setLoading(false); }
  };

  const handleGhostGeneration = async () => {
    if (!ghostFrontImage) return;
    setLoading(true);
    setLoadingMsg("Rendering e-commerce assets...");
    try {
      const results = await generateGhostMannequin(ghostFrontImage, ghostBackImage, (m, p) => { setLoadingMsgSub(m); setLoadingProgress(p); });
      setGeneratedGhostImages(results);
      setStep(AppStep.GHOST_MANNEQUIN_VIEW);
    } catch (e: any) { alert(e.message); } finally { setLoading(false); }
  };

  const handleBannerGeneration = async () => {
    if (!bannerProductImage) return;
    setLoading(true);
    setLoadingMsg("Designing Banners...");
    try {
      const results = await generateBanners(bannerProductImage, selectedBannerPreset, selectedAspectRatio, selectedHoliday, dealText);
      setGeneratedBanners(results);
      setStep(AppStep.BANNER_RESULTS);
    } catch (e: any) { alert(e.message); } finally { setLoading(false); }
  };

  const handlePhotoshootGeneration = async () => {
    if (!photoshootProductImage) return;
    setLoading(true);
    setLoadingMsg("Performing Photoshoot...");
    try {
      const result = await generateModelPhotoshoot(photoshootProductImage, photoshootModelType!, photoshootRealModelImage, photoshootAiConfig);
      setPhotoshootResultImage(result);
      setStep(AppStep.PHOTOSHOOT_RESULTS);
    } catch (e: any) { alert(e.message); } finally { setLoading(false); }
  };

  const handleDownload = (e: React.MouseEvent, base64: string, filename: string) => {
    e.stopPropagation();
    const link = document.createElement("a");
    link.href = `data:image/png;base64,${base64}`;
    link.download = filename + ".png";
    link.click();
  };

  const handleReset = (mode: AppMode = appMode) => {
    setConcepts([]); setSelectedConcept(null); setProductionAssets(null);
    setGhostFrontImage(null); setGhostBackImage(null); setGeneratedGhostImages(null);
    setBannerProductImage(null); setGeneratedBanners([]); 
    setPhotoshootProductImage(null); setPhotoshootModelType(null); setPhotoshootRealModelImage(null); setPhotoshootResultImage(null);
    
    if (mode === 'photoshoot') setStep(AppStep.PHOTOSHOOT_UPLOAD);
    else if (mode === 'banner') setStep(AppStep.BANNER_UPLOAD);
    else if (mode === 'ghost') setStep(AppStep.CATEGORY_SELECT); // Reusing as entry point
    else setStep(AppStep.CATEGORY_SELECT);
  };

  const handleBack = () => {
    if (step === AppStep.PRODUCTION_VIEW) setStep(AppStep.CONCEPT_SELECTION);
    else if (step === AppStep.CONCEPT_SELECTION) setStep(AppStep.CATEGORY_SELECT);
    else if (step === AppStep.PHOTOSHOOT_AI_CONFIG) setStep(AppStep.PHOTOSHOOT_UPLOAD);
    else if (step === AppStep.BANNER_RESULTS) setStep(AppStep.BANNER_UPLOAD);
    else handleReset();
  };

  if (showAdminPanel) return <AdminPanel onClose={() => setShowAdminPanel(false)} />;
  if (showTechPack && selectedConcept && productionAssets) return <TechPack concept={selectedConcept} assets={productionAssets} category={selectedCategory} gender={selectedGender} onClose={() => setShowTechPack(false)} />;
  if (loading) return <LoadingScreen message={loadingMsg} subMessage={loadingMsgSub} progress={loadingProgress} />;

  return (
    <div className="min-h-screen flex flex-col bg-neutral-950 text-white font-sans selection:bg-purple-500 selection:text-white no-print">
      <header className="sticky top-0 z-40 bg-black/80 backdrop-blur-md border-b border-white/10 p-4 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4 w-full md:w-auto">
          {step !== AppStep.CATEGORY_SELECT && step !== AppStep.BANNER_UPLOAD && step !== AppStep.PHOTOSHOOT_UPLOAD && <button onClick={handleBack} className="text-gray-400 hover:text-white transition-colors"><BackIcon /></button>}
          <h1 className="text-2xl font-bold tracking-tighter brand-font uppercase">CULTURE<span className="text-purple-500">PIECE</span></h1>
          <div className="hidden lg:flex items-center ml-4 px-3 py-1 bg-purple-950/20 rounded-full border border-purple-500/30">
             <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest mr-2">GLOBAL PIECES:</span>
             <span className="text-sm font-mono font-bold text-white">{globalStats.totalGenerations.toLocaleString()}</span>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-black p-1 border border-white/10">
          {['designer', 'ghost', 'banner', 'photoshoot'].map((m) => (
            <button key={m} onClick={() => { setAppMode(m as AppMode); handleReset(m as AppMode); }} className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-colors ${appMode === m ? 'bg-white text-black' : 'text-gray-400 hover:bg-white/10'}`}>
              {m.replace(/^\w/, c => c.toUpperCase())}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setShowAdminPanel(true)} className="text-purple-400 hover:text-white flex items-center gap-1 text-xs font-bold uppercase tracking-wider"><AdminIcon /> Admin</button>
          <button onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase border border-white/20 hover:border-purple-500 bg-black/50 rounded-full transition-all">
            {logo ? "Logo Active" : "Upload Brand Logo"}
          </button>
          {!hasKey && <Button variant="secondary" onClick={handleKeySelect} className="text-xs">Connect API</Button>}
        </div>
      </header>

      <main className="flex-grow container mx-auto p-4 md:p-8">
        {/* DESIGNER MODE - CATEGORY SELECT */}
        {appMode === 'designer' && step === AppStep.CATEGORY_SELECT && (
          <div className="max-w-6xl mx-auto animate-fade-in">
            <div className="mb-12 text-center space-y-4">
              <h2 className="text-5xl font-bold brand-font uppercase">Collection Studio</h2>
              <div className="flex justify-center gap-4 mt-6">
                {[Gender.MALE, Gender.FEMALE].map((g) => (
                  <button key={g} onClick={() => setSelectedGender(g)} className={`px-6 py-2 rounded-full border text-sm uppercase transition-all ${selectedGender === g ? 'bg-white text-black font-bold' : 'text-gray-500 border-gray-700'}`}>{g}</button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {CATEGORIES.map((cat) => {
                const Icon = CATEGORY_ICONS[cat];
                return (
                  <button key={cat} onClick={() => { setSelectedCategory(cat); setShowStyleChoiceModal(true); }} className="group aspect-square flex flex-col items-center justify-center gap-4 p-4 border border-white/10 hover:border-purple-500 hover:bg-white/5 transition-all">
                    <div className="text-gray-400 group-hover:text-purple-400">{Icon && <Icon />}</div>
                    <span className="text-center font-bold text-sm uppercase tracking-wider text-gray-300">{cat}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* GHOST MODE - UPLOAD */}
        {appMode === 'ghost' && step === AppStep.CATEGORY_SELECT && (
           <div className="max-w-4xl mx-auto animate-fade-in py-12">
              <h2 className="text-4xl font-bold brand-font uppercase mb-12 text-center">E-Commerce Ghost Studio</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                 <div className="flex flex-col items-center space-y-4">
                    <span className="text-xs font-bold uppercase tracking-widest text-purple-400">Front View (Required)</span>
                    <button onClick={() => ghostFrontRef.current?.click()} className="w-full aspect-[3/4] border-2 border-dashed border-white/10 hover:border-purple-500 bg-white/5 flex flex-col items-center justify-center overflow-hidden transition-all">
                       {ghostFrontImage ? <img src={ghostFrontImage} className="w-full h-full object-contain p-4" /> : <div className="text-center p-8 text-gray-500"><UploadIcon className="mx-auto mb-2"/><p className="text-xs font-bold uppercase">Upload Front</p></div>}
                    </button>
                 </div>
                 <div className="flex flex-col items-center space-y-4">
                    <span className="text-xs font-bold uppercase tracking-widest text-gray-500">Back View (Optional)</span>
                    <button onClick={() => ghostBackRef.current?.click()} className="w-full aspect-[3/4] border-2 border-dashed border-white/10 hover:border-purple-500 bg-white/5 flex flex-col items-center justify-center overflow-hidden transition-all">
                       {ghostBackImage ? <img src={ghostBackImage} className="w-full h-full object-contain p-4" /> : <div className="text-center p-8 text-gray-500"><UploadIcon className="mx-auto mb-2"/><p className="text-xs font-bold uppercase">Upload Back</p></div>}
                    </button>
                 </div>
              </div>
              <div className="flex justify-center">
                 <Button className="px-12 py-4 text-lg" onClick={handleGhostGeneration} disabled={!ghostFrontImage}>Process 2K Assets</Button>
              </div>
           </div>
        )}

        {/* GHOST MODE - RESULTS */}
        {appMode === 'ghost' && step === AppStep.GHOST_MANNEQUIN_VIEW && generatedGhostImages && (
           <div className="max-w-5xl mx-auto animate-fade-in py-12">
              <h2 className="text-3xl font-bold brand-font uppercase mb-8 border-b border-white/10 pb-4">Ghost Mannequin Results</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div className="bg-neutral-900 border border-white/10 p-4 space-y-4">
                    <div className="aspect-[3/4] bg-white relative group">
                       <img src={`data:image/png;base64,${generatedGhostImages.front}`} className="w-full h-full object-contain" />
                       <button onClick={(e) => handleDownload(e, generatedGhostImages.front, 'Ghost_Front')} className="absolute top-4 right-4 p-3 bg-black/50 rounded-full"><DownloadIcon /></button>
                    </div>
                    <p className="text-center text-xs font-bold uppercase tracking-widest">Front View</p>
                 </div>
                 {generatedGhostImages.back && (
                   <div className="bg-neutral-900 border border-white/10 p-4 space-y-4">
                      <div className="aspect-[3/4] bg-white relative group">
                         <img src={`data:image/png;base64,${generatedGhostImages.back}`} className="w-full h-full object-contain" />
                         <button onClick={(e) => handleDownload(e, generatedGhostImages.back!, 'Ghost_Back')} className="absolute top-4 right-4 p-3 bg-black/50 rounded-full"><DownloadIcon /></button>
                      </div>
                      <p className="text-center text-xs font-bold uppercase tracking-widest">Back View</p>
                   </div>
                 )}
              </div>
              <div className="mt-12 flex justify-center gap-4">
                 <Button variant="outline" onClick={() => handleReset('ghost')}>New Item</Button>
              </div>
           </div>
        )}

        {/* BANNER MODE - UPLOAD */}
        {appMode === 'banner' && step === AppStep.BANNER_UPLOAD && (
           <div className="max-w-5xl mx-auto animate-fade-in py-12">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                 <div className="space-y-6">
                    <h2 className="text-4xl font-bold brand-font uppercase">Banner Design Studio</h2>
                    <p className="text-gray-400 text-sm">Upload your ghost mannequin or product flatlay to generate market-ready social media assets.</p>
                    <button onClick={() => bannerProductRef.current?.click()} className="w-full aspect-square border-2 border-dashed border-white/10 hover:border-purple-500 bg-white/5 flex flex-col items-center justify-center overflow-hidden transition-all">
                       {bannerProductImage ? <img src={bannerProductImage} className="w-full h-full object-contain p-4" /> : <div className="text-center p-8 text-gray-500"><UploadIcon className="mx-auto mb-2"/><p className="text-xs font-bold uppercase">Upload Product Image</p></div>}
                    </button>
                 </div>
                 <div className="bg-neutral-900 border border-white/10 p-8 space-y-6 self-start">
                    <h3 className="text-xl font-bold brand-font uppercase text-purple-400">Campaign Config</h3>
                    <div>
                       <label className="block text-xs font-bold uppercase tracking-widest mb-2">Artistic Preset</label>
                       <select value={selectedBannerPreset} onChange={(e) => setSelectedBannerPreset(e.target.value)} className="w-full bg-black border border-white/20 p-3 text-sm outline-none focus:border-purple-500">
                          {BANNER_PRESETS.map(p => <option key={p} value={p}>{p}</option>)}
                       </select>
                    </div>
                    <div>
                       <label className="block text-xs font-bold uppercase tracking-widest mb-2">Aspect Ratio</label>
                       <select value={selectedAspectRatio} onChange={(e) => setSelectedAspectRatio(e.target.value)} className="w-full bg-black border border-white/20 p-3 text-sm outline-none focus:border-purple-500">
                          {Object.entries(ASPECT_RATIOS).map(([label, val]) => <option key={val} value={val}>{label}</option>)}
                       </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div>
                          <label className="block text-xs font-bold uppercase tracking-widest mb-2">Holiday Event</label>
                          <select value={selectedHoliday} onChange={(e) => setSelectedHoliday(e.target.value)} className="w-full bg-black border border-white/20 p-3 text-sm outline-none focus:border-purple-500">
                             {HOLIDAY_PRESETS.map(h => <option key={h} value={h}>{h}</option>)}
                          </select>
                       </div>
                       <div>
                          <label className="block text-xs font-bold uppercase tracking-widest mb-2">Promo Code/Deal</label>
                          <input type="text" value={dealText} onChange={(e) => setDealText(e.target.value)} placeholder="e.g. 50% OFF" className="w-full bg-black border border-white/20 p-3 text-sm outline-none focus:border-purple-500" />
                       </div>
                    </div>
                    <Button fullWidth className="py-4" onClick={handleBannerGeneration} disabled={!bannerProductImage}>Design Banners</Button>
                 </div>
              </div>
           </div>
        )}

        {/* BANNER MODE - RESULTS */}
        {appMode === 'banner' && step === AppStep.BANNER_RESULTS && (
           <div className="max-w-6xl mx-auto animate-fade-in py-12">
              <h2 className="text-3xl font-bold brand-font uppercase mb-12 border-b border-white/10 pb-4">Designer Banners</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 {generatedBanners.map((b, i) => (
                    <div key={i} className="group relative bg-neutral-900 border border-white/10 overflow-hidden">
                       <img src={`data:image/png;base64,${b}`} className="w-full h-auto object-cover" />
                       <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <Button onClick={(e) => handleDownload(e, b, `Banner_${i}`)}>Download 2K</Button>
                       </div>
                    </div>
                 ))}
              </div>
              <div className="mt-12 flex justify-center"><Button variant="outline" onClick={() => handleReset('banner')}>New Campaign</Button></div>
           </div>
        )}

        {/* PHOTOSHOOT MODE - UPLOAD */}
        {appMode === 'photoshoot' && step === AppStep.PHOTOSHOOT_UPLOAD && (
          <div className="animate-fade-in max-w-4xl mx-auto py-12">
            <h2 className="text-4xl font-bold brand-font uppercase mb-12 text-center">AI Lifestyle Studio</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="flex flex-col items-center">
                <h3 className="text-lg font-bold uppercase mb-4 brand-font text-purple-400">1. Product Image</h3>
                <button onClick={() => photoshootProductRef.current?.click()} className="w-full aspect-[3/4] border-2 border-dashed border-white/10 hover:border-purple-500 flex items-center justify-center bg-white/5 overflow-hidden transition-all">
                  {photoshootProductImage ? <img src={photoshootProductImage} className="w-full h-full object-contain p-4" /> : <div className="text-gray-500 text-center"><UploadIcon className="mx-auto mb-2"/><p className="text-xs font-bold uppercase">Upload Flatlay</p></div>}
                </button>
              </div>
              <div className="space-y-6">
                <h3 className="text-lg font-bold uppercase mb-4 brand-font text-purple-400">2. Shoot Direction</h3>
                <Button fullWidth className="py-6" onClick={() => { setPhotoshootModelType('ai'); setStep(AppStep.PHOTOSHOOT_AI_CONFIG); }} disabled={!photoshootProductImage}>AI Model Photoshoot</Button>
                <div className="relative"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10"></div></div><div className="relative flex justify-center text-xs uppercase font-bold text-gray-500 bg-neutral-950 px-2">OR</div></div>
                <Button fullWidth variant="outline" className="py-6" onClick={() => { setPhotoshootModelType('real'); photoshootRealModelRef.current?.click(); }} disabled={!photoshootProductImage}>Virtual Try-On (Human Model)</Button>
                {photoshootRealModelImage && photoshootModelType === 'real' && (
                  <div className="mt-8 animate-fade-in flex flex-col items-center p-6 bg-white/5 border border-white/10">
                    <img src={photoshootRealModelImage} className="w-48 aspect-[3/4] object-contain mb-4 border border-white/10" />
                    <Button onClick={handlePhotoshootGeneration}>Perform Try-On</Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* PHOTOSHOOT MODE - AI CONFIG */}
        {appMode === 'photoshoot' && step === AppStep.PHOTOSHOOT_AI_CONFIG && (
           <div className="max-w-4xl mx-auto animate-fade-in py-12">
              <h2 className="text-3xl font-bold brand-font uppercase mb-12 text-center">Cast Your Model & Scene</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-neutral-900 border border-white/10 p-8">
                 <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-purple-400">Model Specs</h3>
                    <div className="grid grid-cols-2 gap-4">
                       <div>
                          <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Gender</label>
                          <select value={photoshootAiConfig.gender} onChange={(e) => setPhotoshootAiConfig({...photoshootAiConfig, gender: e.target.value as Gender})} className="w-full bg-black border border-white/20 p-2 text-sm">
                             <option value={Gender.MALE}>Male</option>
                             <option value={Gender.FEMALE}>Female</option>
                          </select>
                       </div>
                       <div>
                          <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Ethnicity</label>
                          <select value={photoshootAiConfig.ethnicity} onChange={(e) => setPhotoshootAiConfig({...photoshootAiConfig, ethnicity: e.target.value})} className="w-full bg-black border border-white/20 p-2 text-sm">
                             {AI_MODEL_ETHNICITY.map(e => <option key={e} value={e}>{e}</option>)}
                          </select>
                       </div>
                    </div>
                    <div>
                       <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Age Range</label>
                       <select value={photoshootAiConfig.age} onChange={(e) => setPhotoshootAiConfig({...photoshootAiConfig, age: e.target.value})} className="w-full bg-black border border-white/20 p-2 text-sm">
                          {AI_MODEL_AGE.map(a => <option key={a} value={a}>{a}</option>)}
                       </select>
                    </div>
                 </div>
                 <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-purple-400">Environment</h3>
                    <div>
                       <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Scene</label>
                       <select value={photoshootAiConfig.scene} onChange={(e) => setPhotoshootAiConfig({...photoshootAiConfig, scene: e.target.value})} className="w-full bg-black border border-white/20 p-2 text-sm">
                          {AI_MODEL_SCENE.map(s => <option key={s} value={s}>{s}</option>)}
                       </select>
                    </div>
                    <div>
                       <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Pose/Action</label>
                       <select value={photoshootAiConfig.action} onChange={(e) => setPhotoshootAiConfig({...photoshootAiConfig, action: e.target.value})} className="w-full bg-black border border-white/20 p-2 text-sm">
                          {AI_MODEL_ACTION.map(a => <option key={a} value={a}>{a}</option>)}
                       </select>
                    </div>
                 </div>
              </div>
              <div className="mt-12 flex justify-center">
                 <Button className="px-12 py-4" onClick={handlePhotoshootGeneration}>Start Photoshoot</Button>
              </div>
           </div>
        )}

        {/* CONCEPT SELECTION (DESIGNER) */}
        {step === AppStep.CONCEPT_SELECTION && (
          <div className="animate-fade-in max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold brand-font uppercase mb-8 border-b border-white/10 pb-6">Select Concept</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {concepts.map((concept) => (
                <div key={concept.id} className="bg-neutral-900 border border-white/10 hover:border-purple-500 transition-all group overflow-hidden">
                  <div className="aspect-[4/3] bg-white p-4"><img src={`data:image/png;base64,${concept.imageBase64}`} className="w-full h-full object-contain" /></div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold brand-font uppercase mb-2 text-purple-400">{concept.title}</h3>
                    <p className="text-gray-400 text-sm mb-6 line-clamp-2">{concept.description}</p>
                    <Button fullWidth onClick={() => finalizeDesign(concept)}>Generate Assets</Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* PRODUCTION VIEW (DESIGNER) */}
        {appMode === 'designer' && step === AppStep.PRODUCTION_VIEW && productionAssets && selectedConcept && (
          <div className="animate-fade-in space-y-12 pb-24">
            <div className="text-center"><h2 className="text-5xl font-bold brand-font uppercase">{selectedConcept.title}</h2></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
               {[ {t:"Front",i:productionAssets.front}, {t:"Back",i:productionAssets.back}, {t:"Side",i:productionAssets.side}, {t:"Detail",i:productionAssets.closeup}].map((item, idx) => (
                 <div key={idx} className="space-y-3 group">
                   <div className="aspect-square bg-white relative overflow-hidden">
                     <img src={`data:image/png;base64,${item.i}`} className="w-full h-full object-contain" />
                     <button onClick={(e) => handleDownload(e, item.i, `${selectedConcept.title}_${item.t}`)} className="absolute top-2 right-2 p-2 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity"><DownloadIcon /></button>
                   </div>
                 </div>
               ))}
            </div>
            <div className="relative aspect-[16/9] border border-white/10 overflow-hidden group">
              <img src={`data:image/png;base64,${productionAssets.lifestyle}`} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-8 left-8"><h3 className="text-4xl font-bold brand-font uppercase">Lifestyle Campaign</h3></div>
              <button onClick={(e) => handleDownload(e, productionAssets.lifestyle, `Lifestyle`)} className="absolute top-8 right-8 p-3 bg-black/50 rounded-full"><DownloadIcon /></button>
            </div>
            <div className="flex justify-center gap-4"><Button variant="outline" onClick={() => handleReset()}>New Design</Button><Button onClick={() => setShowTechPack(true)}>Export Spec Sheet</Button></div>
          </div>
        )}

        {/* PHOTOSHOOT RESULTS */}
        {appMode === 'photoshoot' && step === AppStep.PHOTOSHOOT_RESULTS && photoshootResultImage && (
          <div className="max-w-2xl mx-auto py-12 animate-fade-in">
             <div className="aspect-[3/4] bg-neutral-900 border border-white/10 relative group mb-8">
               <img src={`data:image/png;base64,${photoshootResultImage}`} className="w-full h-full object-contain" />
               <button onClick={(e) => handleDownload(e, photoshootResultImage, 'Photoshoot')} className="absolute top-4 right-4 p-3 bg-black/50 rounded-full"><DownloadIcon /></button>
             </div>
             <div className="flex justify-center"><Button variant="outline" onClick={() => handleReset('photoshoot')}>Create Another</Button></div>
          </div>
        )}
      </main>

      {/* Hidden File Inputs */}
      <input type="file" accept="image/*" ref={fileInputRef} onChange={(e) => handleImageUpload(e, setLogo)} className="hidden" />
      <input type="file" accept="image/*" ref={ghostFrontRef} onChange={(e) => handleImageUpload(e, setGhostFrontImage)} className="hidden" />
      <input type="file" accept="image/*" ref={ghostBackRef} onChange={(e) => handleImageUpload(e, setGhostBackImage)} className="hidden" />
      <input type="file" accept="image/*" ref={bannerProductRef} onChange={(e) => handleImageUpload(e, setBannerProductImage)} className="hidden" />
      <input type="file" accept="image/*" ref={photoshootProductRef} onChange={(e) => handleImageUpload(e, setPhotoshootProductImage)} className="hidden" />
      <input type="file" accept="image/*" ref={photoshootRealModelRef} onChange={(e) => handleImageUpload(e, setPhotoshootRealModelImage)} className="hidden" />

      {/* Style Choice Modal */}
      {showStyleChoiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4">
          <div className="bg-neutral-900 border border-white/20 p-8 w-full max-w-lg shadow-2xl">
            <h2 className="text-2xl font-bold brand-font mb-8 uppercase text-center text-white">Select Direction</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button onClick={() => { setShowStyleChoiceModal(false); startDesignProcess(selectedCategory, 'genz-us'); }} className="p-8 border border-white/10 hover:border-purple-500 bg-black hover:bg-neutral-800 transition-all text-left">
                <h3 className="text-xl font-bold text-purple-400 mb-2">US STREETWEAR</h3>
                <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Baggy Fits • Bold Details</p>
              </button>
              <button onClick={() => { setShowStyleChoiceModal(false); startDesignProcess(selectedCategory, 'european'); }} className="p-8 border border-white/10 hover:border-purple-500 bg-black hover:bg-neutral-800 transition-all text-left">
                <h3 className="text-xl font-bold text-purple-400 mb-2">EURO MINIMALIST</h3>
                <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Clean Lines • Tech Fabrics</p>
              </button>
            </div>
            <div className="mt-12 text-center"><button onClick={() => setShowStyleChoiceModal(false)} className="text-gray-500 hover:text-white uppercase text-xs font-bold tracking-widest">Go Back</button></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
