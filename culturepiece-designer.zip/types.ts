
export enum AppStep {
  CATEGORY_SELECT = 'CATEGORY_SELECT',
  CONCEPT_GENERATION = 'CONCEPT_GENERATION',
  CONCEPT_SELECTION = 'CONCEPT_SELECTION',
  PRODUCTION_VIEW = 'PRODUCTION_VIEW',
  GHOST_MANNEQUIN_VIEW = 'GHOST_MANNEQUIN_VIEW',
  BANNER_UPLOAD = 'BANNER_UPLOAD',
  BANNER_RESULTS = 'BANNER_RESULTS',
  PHOTOSHOOT_UPLOAD = 'PHOTOSHOOT_UPLOAD',
  PHOTOSHOOT_AI_CONFIG = 'PHOTOSHOOT_AI_CONFIG',
  PHOTOSHOOT_RESULTS = 'PHOTOSHOOT_RESULTS',
}

export type AppMode = 'designer' | 'ghost' | 'banner' | 'photoshoot';

export enum Gender {
  MALE = 'Male',
  FEMALE = 'Female',
}

export type UserRole = 'user' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  credits: number;
  role: UserRole;
  createdAt: number;
}

export interface Concept {
  id: number;
  title: string;
  description: string;
  imageBase64: string;
}

export interface ProductionAssets {
  front: string;
  back:string;
  closeup: string;
  side: string;
  lifestyle: string;
}

export const CATEGORIES = [
  "Trousers", "Shorts", "Tracksuits", "T-Shirts", 
  "Denim Jackets", "Puffer Jackets", "Hunting Jackets", "Crop Tops", 
  "Leggings", "Hoodies", "Soccer Uniforms", "American Football Uniform",
  "Baseball Jersey", "Ice Hockey Jersey", "Ski Jackets"
];

export const SOCCER_PRESETS = [
  "Classic Stripes", "Modern Minimalist", "Abstract Graphic", "Cultural Pattern"
];

export const PUFFER_JACKET_PRESETS = [
  "No Preset", "Cropped Boxy Puffer", "Longline Duvet Puffer", "Technical Gorpcore Puffer", "Sleeveless Gilet/Vest", "Wet-Look Vinyl Puffer", "Classic Expedition Puffer"
];

export const BANNER_PRESETS = [
  "Minimalist Product Focus", "Urban Street Style", "Bold Typography", "Luxury Editorial", "Y2K/Retro Futuristic", "Collage/Scrapbook", "Action/Sports", "Natural/Organic"
];

export const ASPECT_RATIOS: Record<string, string> = {
  "Instagram Post (1:1)": "1:1",
  "Instagram Story (9:16)": "9:16",
  "Facebook Post (4:5)": "4:5", // Note: Will be mapped to nearest supported ratio
  "Pinterest Pin (2:3)": "2:3", // Note: Will be mapped to nearest supported ratio
};

export const HOLIDAY_PRESETS = [
  "None", "Black Friday", "Cyber Monday", "Christmas", "New Year's", "Valentine's Day", "Mother's Day", "Father's Day", "4th of July", "Halloween", "Easter", "Thanksgiving", "Labor Day", "Memorial Day", "11.11 Sale"
];

// --- Photoshoot Presets ---
export const AI_MODEL_ETHNICITY = ["Black", "White", "Asian", "Hispanic", "Middle Eastern", "Mixed"];
export const AI_MODEL_AGE = ["18-25", "25-35", "35-45"];
export const AI_MODEL_SCENE = ["Urban Cityscape", "Minimalist Studio", "Nature/Hiking", "Luxury Interior", "Beach/Coastal", "Disco/Party"];
export const AI_MODEL_ACTION = ["Standing/Posing", "Walking", "Sitting", "Dancing", "Running", "Fighting"];
